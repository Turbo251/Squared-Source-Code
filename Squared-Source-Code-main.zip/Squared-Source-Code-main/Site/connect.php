<?php

	$host = "54.38.50.59";
	$db_user = "www7874_exoro";
	$db_password = "hvHBGzyWs836qHaasGDq";
	$db_name = "www7874_exoro";

?>