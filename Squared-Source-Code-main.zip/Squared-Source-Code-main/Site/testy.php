<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
    <title>Squared - Home</title>
    <meta property="og:site_name" content="Squared">
    <meta property="og:title" content="Squared - Home">
    <meta property="og:type" content="profile">
    <meta property="og:url" content="https://squared.cf/">
    <meta property="og:description" content="Squared, it is website. He is for old brick-builder. Good for use.">
    <meta property="og:image" content="https://cdn.upload.systems/uploads/pDPrTMVK.png">
</head>
<body>
<center>ur mom</center>
</body>
</html>