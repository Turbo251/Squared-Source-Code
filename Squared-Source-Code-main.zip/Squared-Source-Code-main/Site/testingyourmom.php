
<?php $date = new DateTime("now", new DateTimeZone('Europe/Warsaw') );echo "if you see this please report it to staff, " .  $date->format('Y-m-d H:i:s'); ?>