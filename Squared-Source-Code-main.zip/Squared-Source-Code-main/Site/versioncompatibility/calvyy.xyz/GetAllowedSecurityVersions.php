<?php
$stringssecurityversions = array("0.249.0pcplayer");

$securityversions = array(
    "data" => $stringssecurityversions
);

echo json_encode($securityversions);

// For late - 0.271.1pcplayer, for mid - 0.249.0pcplayer