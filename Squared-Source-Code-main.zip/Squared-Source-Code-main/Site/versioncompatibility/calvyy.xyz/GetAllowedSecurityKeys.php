<?php
$stringseckeys = array("76E5A40C-3AE1-4028-9F10-7C62520BD94F");

$securitykeys = array(
    "data" => $stringseckeys
);

echo json_encode($securitykeys);
//echo"true";