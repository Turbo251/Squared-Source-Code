<?php
$stringsmd5 = array("2d72464b992be3ee821397fdce9f7a25","b922dd76195207766b6a794cb3616328");

$md5 = array(
    "data" => $stringsmd5
);

echo json_encode($md5);