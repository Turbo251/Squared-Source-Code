<?php 
$bypassModeration = true;
require $_SERVER['DOCUMENT_ROOT'].'/api/private/core.php'; 
pageBuilder::buildHeader();
?>

no doodama
<br><br>
absolutely no doodama
<br><br>
dear god

<?php pageBuilder::buildFooter(); ?>
