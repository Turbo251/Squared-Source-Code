<?php 
require $_SERVER['DOCUMENT_ROOT'].'/api/private/core.php'; 
pageBuilder::errorCode($_GET['code']);	
