<?php
class info {
    public $sitename = "Exoro";
    public $siteurl = "https://exoro.ml";
    public $siteip = "18.170.60.75";
}
?>