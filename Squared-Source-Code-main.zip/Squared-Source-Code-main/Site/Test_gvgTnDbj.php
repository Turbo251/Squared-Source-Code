<!DOCTYPE html>
<html xmlns="https://www.w3.org/1999/xhtml" xml:lang="en" xmlns:fb="https://www.facebook.com/2008/fbml">
   <head>
    <?php include_once "2014head.php"; ?>
    <?php 
        require_once "DiscordEmbed.php";
        $discordembed = new DiscordEmbed(); 
        $discordembed->NormalEmbed("Home", "https://squared.cf/Default.aspx");
    ?>
      <script src="/sdf.js" type="text/javascript"></script>
      <head>
<meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true">
<script type="text/javascript" id="www-widgetapi-script" src="https://www.youtube.com/s/player/ad2aeb77/www-widgetapi.vflset/www-widgetapi.js" async=""></script><script type="text/javascript" async="" src="https://ssltracking/.esearchvision.com/esi/esearchvisiontracking.js"></script><script type="text/javascript" async="" src="https://ssltracking.esearchvision.com/esi/esearchvisiontracking.js"></script><script type="text/javascript" async="" src="https://ssl/.google-analytics.com/ga.js"></script><script src="https://www.youtube.com/iframe_api"></script><script async="" type="text/javascript" src="https://www.googletagservices.com/tag/js/gpt.js"></script><script type="text/javascript" src="/js/modules/Widgets/AvatarImage.js"></script><script type="text/javascript" src="/js/modules/Widgets/ItemImage.js"></script><script type="text/javascript" src="/js/modules/Widgets/PlaceImage.js"></script><script type="text/javascript" src="/js/modules/Widgets/GroupImage.js"></script><script type="text/javascript" src="/js/modules/Widgets/DropdownMenu.js"></script><script type="text/javascript" async="" src="https://ssl/.google-analytics.com/ga.js"></script><script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-11419793-1']);
    _gaq.push(['_setCampSourceKey', 'rbx_source']);
    _gaq.push(['_setCampMediumKey', 'rbx_medium']);
    _gaq.push(['_setCampContentKey', 'rbx_campaign']);
    
    
    
    _gaq.push(['b._setAccount', 'UA-486632-1']);
    _gaq.push(['b._setCampSourceKey', 'rbx_source']);
    _gaq.push(['b._setCampMediumKey', 'rbx_medium']);
    _gaq.push(['b._setCampContentKey', 'rbx_campaign']);

    
        _gaq.push(['c._setAccount', 'UA-26810151-2']);
		
		// ROBLONIUM.com Google Analytics
		_gaq.push(['_setAccount', 'UA-175671538-1']);
		_gaq.push(['b._setAccount', 'UA-175671538-1']);
		_gaq.push(['c._setAccount', 'UA-175671538-1']);
    

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl/' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
  </script>

<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.2.min.js"></script>
<script type="text/javascript">window.jQuery || document.write("<script type='text/javascript' src='/js/jquery/jquery-1.7.2.min.js'><\/script>")</script>
<script src="https://ajax.aspnetcdn.com/ajax/4.0/1/WebForms.js" type="text/javascript"></script>
<script type="text/javascript">window.WebForm_PostBackOptions||document.write('<script type="text/javascript" src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZH6GgOgBQtqMPCPjRUnhj_pzNesAXKuAdu2pj-Sq-3JDJIgwEw2&amp;t=635792847671809273"><\/script>');//]]></script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjax.js"></script>
<script type="text/javascript">window.Sys || document.write("<script type='text/javascript' src='/js/Microsoft/MicrosoftAjax.js'><\/script>")</script>
<script src="https://ajax.aspnetcdn.com/ajax/4.0/1/MicrosoftAjaxWebForms.js" type="text/javascript"></script>
<script type="text/javascript">(window.Sys && Sys.WebForms)||document.write('<script type="text/javascript" src="/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OC_Qyj6iPZ9-IhfgU1PKd92NqwesSi5IgR2kHUAQCLPPKv5dmGb59sQmqQu3G6_D3NKJrjUgXZeod0TXb9neDij-vtT2tW5WrVuyLXf9BqECFbVGd3-sTKQ_7e03iLz9XRbz2Yc1&t=72e85ccd"><\/script>');//]]></script>

<script type="text/javascript" src="/js/roblox.js"></script>
<script type="text/javascript" src="/js/widgets.js"></script>
<script type="text/javascript">
    var Roblox = Roblox || {};
    Roblox.EnvironmentUrls = Roblox.EnvironmentUrls || {};
Roblox.EnvironmentUrls = {
    "abtestingApiSite": "http://abtesting.sitetest1.roblonium.com",
    "accountInformationApi": "http://accountinformation.sitetest1.roblonium.com",
    "accountSettingsApi": "http://accountsettings.sitetest1.roblonium.com",
    "apiGatewayUrl": "http://apis.sitetest1.roblonium.com",
    "apiProxyUrl": "http://api.sitetest1.roblonium.com",
    "assetDeliveryApi": "http://assetdelivery.sitetest1.roblonium.com",
    "authApi": "http://auth.sitetest1.roblonium.com",
    "authAppSite": "http://authsite.sitetest1.roblonium.com",
    "avatarApi": "http://avatar.sitetest1.roblonium.com",
    "badgesApi": "http://badges.sitetest1.roblonium.com",
    "billingApi": "http://billing.sitetest1.roblonium.com",
    "captchaApi": "http://captcha.sitetest1.roblonium.com",
    "catalogApi": "http://catalog.sitetest1.roblonium.com",
    "chatApi": "http://chat.sitetest1.roblonium.com",
    "contactsApi": "http://contacts.sitetest1.roblonium.com",
    "developApi": "http://develop.sitetest1.roblonium.com",
    "domain": "sitetest1.roblonium.com",
    "economyApi": "http://economy.sitetest1.roblonium.com",
    "engagementPayoutsApi": "http://engagementpayouts.sitetest1.roblonium.com",
    "followingsApi": "http://followings.sitetest1.roblonium.com",
    "friendsApi": "http://friends.sitetest1.roblonium.com",
    "friendsAppSite": "http://friendsite.sitetest1.roblonium.com",
    "gamesApi": "http://games.sitetest1.roblonium.com",
    "gameInternationalizationApi": "http://gameinternationalization.sitetest1.roblonium.com",
    "groupsApi": "http://groups.sitetest1.roblonium.com",
    "inventoryApi": "http://inventory.sitetest1.roblonium.com",
    "itemConfigurationApi": "http://itemconfiguration.sitetest1.roblonium.com",
    "localeApi": "http://locale.sitetest1.roblonium.com",
    "localizationTablesApi": "http://localizationtables.sitetest1.roblonium.com",
    "metricsApi": "http://metrics.sitetest1.roblonium.com",
    "midasApi": "http://midas.sitetest1.roblonium.com",
    "notificationApi": "http://notifications.sitetest1.roblonium.com",
    "premiumFeaturesApi": "http://premiumfeatures.sitetest1.roblonium.com",
    "presenceApi": "http://presence.sitetest1.roblonium.com",
    "publishApi": "http://publish.sitetest1.roblonium.com",
    "thumbnailsApi": "http://thumbnails.sitetest1.roblonium.com",
    "translationRolesApi": "http://translationroles.sitetest1.roblonium.com",
    "universalAppConfigurationApi": "http://apis.sitetest1.roblonium.com/universal-app-configuration",
    "usersApi": "http://users.sitetest1.roblonium.com",
    "voiceApi": "http://voice.sitetest1.roblonium.com",
    //"websiteUrl": "http://www.sitetest1.roblonium.com"
	"websiteUrl": ""
};

    // please keep the list in alphabetical order
    var additionalUrls = {
    }

    for (var urlName in additionalUrls) {
        Roblox.EnvironmentUrls[urlName] = additionalUrls[urlName];
    }
</script>


<script type="text/javascript">
    Roblox.config.externalResources = [];
    Roblox.config.paths['Pages.Catalog'] = '/js/modules/Pages/Catalog.js';
    Roblox.config.paths['Pages.CatalogShared'] = '/js/modules/Pages/CatalogShared.js';
    Roblox.config.paths['Pages.Messages'] = '/js/modules/Pages/Messages.js';
    Roblox.config.paths['Resources.Messages'] = '/js/modules/Resources/Messages.js';
    Roblox.config.paths['Widgets.AvatarImage'] = '/js/modules/Widgets/AvatarImage.js';
    Roblox.config.paths['Widgets.DropdownMenu'] = '/js/modules/Widgets/DropdownMenu.js';
    Roblox.config.paths['Widgets.GroupImage'] = '/js/modules/Widgets/GroupImage.js';
    Roblox.config.paths['Widgets.HierarchicalDropdown'] = '/js/modules/Widgets/HierarchicalDropdown.js';
    Roblox.config.paths['Widgets.ItemImage'] = '/js/modules/Widgets/ItemImage.js';
    Roblox.config.paths['Widgets.PlaceImage'] = '/js/modules/Widgets/PlaceImage.js';
    Roblox.config.paths['Widgets.SurveyModal'] = '/js/modules/Widgets/SurveyModal.js';
</script>

<script type="text/javascript">
    $(function () {
        Roblox.JSErrorTracker.initialize({ 'suppressConsoleError': true});
    });
</script>

<script type="text/javascript" src="/js/ImageControl.js"></script>
<script type="text/javascript" src="/js/DataPager.js"></script>
<script type="text/javascript" src="/js/Page.js?update=true"></script>

<script type="text/javascript" src="/js/Chat.js"></script>

<script type="text/javascript" src="/js/RobloxJsonCookie.js"></script>
<script type="text/javascript" src="/js/jquery-extensions.js"></script>
<script type="text/javascript" src="/js/GPTAdScript.js"></script>

<script type="text/javascript" src="/js/jquery.json-2.2.js"></script>
<script type="text/javascript" src="/js/jquery.simplemodal-1.3.5.js"></script>
<script type="text/javascript" src="/js/jquery.tipsy.js"></script>
<script type="text/javascript" src="/js/AjaxAvatarThumbnail.js"></script>
<script type="text/javascript" src="/js/Extensions/string.js"></script>
<script type="text/javascript" src="/js/StringTruncator.min.js"></script>
<script type="text/javascript" src="/js/json2.min.js"></script>
<script type="text/javascript" src="/js/webkit.js"></script>
<script type="text/javascript" src="/js/GoogleAnalytics/GoogleAnalyticsEvents.js"></script>
<script type="text/javascript" src="/js/MasterPageUI.js"></script>
<script type="text/javascript" src="/js/jquery.cookie.js"></script>
<script type="text/javascript" src="/js/jquery.jsoncookie.js"></script>
<script type="text/javascript" src="/js/JSErrorTracker.js"></script>
<script type="text/javascript" src="/js/XsrfToken.js"></script>
<script type="text/javascript" src="/js/RobloxEventManager.js"></script>
<script type="text/javascript" src="/js/RobloxEventListener.js"></script>
<script type="text/javascript" src="/js/KontagentEventListener.js"></script>
<script type="text/javascript" src="/js/GoogleEventListener.js"></script>
<script type="text/javascript" src="/js/MongoEventListener.js"></script>
<script type="text/javascript" src="/js/SiteTouchEvent.js"></script>
<script type="text/javascript" src="/js/DropDownNav.js"></script>


<script type="text/javascript" src="/js/jquery.filter_input.js"></script>
<script type="text/javascript" src="/js/flot/excanvas.min.js"></script>
<script type="text/javascript" src="/js/flot/jquery.flot.js"></script>
<script type="text/javascript" src="/js/flot/jquery.flot.time.js"></script>
<script type="text/javascript" src="/js/flot/jquery.flot.categories.js"></script>
<script type="text/javascript" src="/js/flot/FlotChart.js"></script>
<script type="text/javascript" src="/js/flot/FlotGraphing.js"></script>
<script type="text/javascript" src="/js/NumberFormatting.js"></script>
<script type="text/javascript" src="/js/MyMoney.js"></script>
<script type="text/javascript" src="/js/jquery/jquery.address-1.5.min.js"></script>
<script type="text/javascript" src="/js/utilities/dialog.js"></script>
<script type="text/javascript" src="/js/utilities/popover.js"></script>
<script type="text/javascript" src="/js/Trade/InventoryItem.js"></script>
<script type="text/javascript" src="/js/Trade/TradeRequest.js"></script>
<script type="text/javascript" src="/js/common/deviceMeta.js"></script>


<script type="text/javascript" src="/js/My/MyItem.js"></script>
<script type="text/javascript" src="/js/PageStyleNotifications.js"></script>
<script type="text/javascript" src="/js/YouTube/RobloxYouTube.js"></script>


<script type="text/javascript" src="/js/EventTracker.js"></script>
<script type="text/javascript" src="/js/ClientInstaller.js"></script>
<script type="text/javascript" src="/js/InstallationInstructions.js"></script>
<script type="text/javascript" src="/js/IEMetroInstructions.js"></script>


<script type="text/javascript" src="/js/RobloxCookies.js"></script>
<script type="text/javascript" src="/js/Sets/SetsPane.js"></script>
<script type="text/javascript" src="/js/ItemPurchase.js"></script>
<script type="text/javascript" src="/js/RobloxEventListener.js"></script>

<script type="text/javascript" src="/js/My/Character.js"></script>
<script type="text/javascript" src="/js/Outfits.js"></script>
<script type="text/javascript" src="/js/widgets/tabs.js"></script>
<script type="text/javascript" src="/js/GenericModal.js"></script>
<script type="text/javascript" src="/js/widgets/jquery.mCustomScrollbar.concat.min.js"></script>
<script type="text/javascript" src="/js/GenericConfirmation.js"></script>


<script type="text/javascript" src="/js/extensions/Thumbnails.js"></script>
<script type="text/javascript" src="/js/extensions/ThreeDeeThumbnails.js"></script>
<script type="text/javascript" src="/js/Thumbnails/ThumbnailView.js"></script>






<script>

        googletag.cmd.push(function() {
            Roblox = Roblox || {};
            Roblox.AdsHelper = Roblox.AdsHelper || {};
            Roblox.AdsHelper.slots = [];
            Roblox.AdsHelper.slots = Roblox.AdsHelper.slots || []; Roblox.AdsHelper.slots.push({slot:googletag.defineSlot("/1015347/Roblox_Games_Middle_300x250", [300, 250], "3139363836383631").addService(googletag.pubads()), id: "3139363836383631", path: "/1015347/Roblox_Games_Middle_300x250"});
Roblox.AdsHelper.slots = Roblox.AdsHelper.slots || []; Roblox.AdsHelper.slots.push({slot:googletag.defineSlot("/1015347/Roblox_Games_Middle_300x250_1", [300, 250], "3232313339393637").addService(googletag.pubads()), id: "3232313339393637", path: "/1015347/Roblox_Games_Middle_300x250_1"});
 
            for (var key in Roblox.AdsHelper.slots) {
                var slot = Roblox.AdsHelper.slots[key].slot;
                var id = Roblox.AdsHelper.slots[key].id;
                var path = Roblox.AdsHelper.slots[key].path;
                
                     slot.setTargeting('pos', path);
                     slot.setTargeting('tier', rtp[path].tier);
                if (slot.renderEnded != "undefined") {
                    (function(slot, id)
                    {
                        slot.renderEndedOld = slot.renderEnded;
                        slot.renderEnded = function() {
                            slot.renderEndedOld();
                            if ($('#' + id + '.gutter').css('display') == "none") {
                                $(document).trigger("GuttersHidden");
                            }
                            if ($('#' + id + '.filmstrip').css('display') == "none") {
                                $(document).trigger("FilmStripHidden");
                            }
                        };    
                    }(slot, id));
                }
            }

            googletag.pubads().setTargeting("Age", "Unknown");	
            googletag.pubads().setTargeting("Env",  "Production");
            googletag.pubads().enableSingleRequest();
            googletag.pubads().collapseEmptyDivs();
            googletag.enableServices();
        });
    </script>
<script type="text/javascript">
    $(function () {
        Roblox.JSErrorTracker.initialize({'internalEventListenerPixelEnabled': true});
    });
</script>
<script type="text/javascript">
    var Roblox = Roblox || {};
    Roblox.UpsellAdModal = Roblox.UpsellAdModal || {};

    Roblox.UpsellAdModal.Resources = {
        //<sl:translate>
        title: "Remove Ads Like This",
        body: "Builders Club members do not see external ads like these.",
        accept: "Upgrade Now",
        decline: "No, thanks"
        //</sl:translate>
    };
</script> <script type="text/javascript">
            Roblox.XsrfToken.setToken('');
        </script>
<script type="text/javascript">
        Roblox.FixedUI.gutterAdsEnabled = false;
    </script>


<script type="text/javascript" src="/js/jquery/jquery.address-1.4.min.js"></script>
<script type="text/javascript" src="/js/GamesDisplay.js"></script>

<script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-11419793-1']);
    _gaq.push(['_setCampSourceKey', 'rbx_source']);
    _gaq.push(['_setCampMediumKey', 'rbx_medium']);
    _gaq.push(['_setCampContentKey', 'rbx_campaign']);
    
    
    
    _gaq.push(['b._setAccount', 'UA-486632-1']);
    _gaq.push(['b._setCampSourceKey', 'rbx_source']);
    _gaq.push(['b._setCampMediumKey', 'rbx_medium']);
    _gaq.push(['b._setCampContentKey', 'rbx_campaign']);

    
        _gaq.push(['c._setAccount', 'UA-26810151-2']);
		
		// ROBLONIUM.com Google Analytics
		_gaq.push(['c._setAccount', 'UA-175671538-1']);
    

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl/' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
</script> <meta http-equiv="origin-trial" content="AxujKG9INjsZ8/gUq8+dTruNvk7RjZQ1oFhhgQbcTJKDnZfbzSTE81wvC2Hzaf3TW4avA76LTZEMdiedF1vIbA4AAABueyJvcmlnaW4iOiJodHRwczovL2ltYXNkay5nb29nbGVhcGlzLmNvbTo0NDMiLCJmZWF0dXJlIjoiVHJ1c3RUb2tlbnMiLCJleHBpcnkiOjE2NTI3NzQ0MDAsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0="><meta http-equiv="origin-trial" content="Azuce85ORtSnWe1MZDTv68qpaW3iHyfL9YbLRy0cwcCZwVnePnOmkUJlG8HGikmOwhZU22dElCcfrfX2HhrBPAkAAAB7eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiVHJ1c3RUb2tlbnMiLCJleHBpcnkiOjE2NTI3NzQ0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="A16nvcdeoOAqrJcmjLRpl1I6f3McDD8EfofAYTt/P/H4/AWwB99nxiPp6kA0fXoiZav908Z8etuL16laFPUdfQsAAACBeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiVHJ1c3RUb2tlbnMiLCJleHBpcnkiOjE2NTI3NzQ0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="AxBHdr0J44vFBQtZUqX9sjiqf5yWZ/OcHRcRMN3H9TH+t90V/j3ENW6C8+igBZFXMJ7G3Pr8Dd13632aLng42wgAAACBeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiVHJ1c3RUb2tlbnMiLCJleHBpcnkiOjE2NTI3NzQ0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"><meta http-equiv="origin-trial" content="A88BWHFjcawUfKU3lIejLoryXoyjooBXLgWmGh+hNcqMK44cugvsI5YZbNarYvi3roc1fYbHA1AVbhAtuHZflgEAAAB2eyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IlRydXN0VG9rZW5zIiwiZXhwaXJ5IjoxNjUyNzc0NDAwLCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="><meta http-equiv="origin-trial" content="A8FHS1NmdCwGqD9DwOicnHHY+y27kdWfxKa0YHSGDfv0CSpDKRHTQdQmZVPDUdaFWUsxdgVxlwAd6o+dhJykPA0AAACWeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQ29udmVyc2lvbk1lYXN1cmVtZW50IiwiZXhwaXJ5IjoxNjQzMTU1MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlLCJ1c2FnZSI6InN1YnNldCJ9"><meta http-equiv="origin-trial" content="A8zdXi6dr1hwXEUjQrYiyYQGlU3557y5QWDnN0Lwgj9ePt66XMEvNkVWOEOWPd7TP9sBQ25X0Q15Lr1Nn4oGFQkAAACceyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQ29udmVyc2lvbk1lYXN1cmVtZW50IiwiZXhwaXJ5IjoxNjQzMTU1MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlLCJ1c2FnZSI6InN1YnNldCJ9"><meta http-equiv="origin-trial" content="A4/Htern2udN9w3yJK9QgWQxQFruxOXsXL7cW60DyCl0EZFGCSme/J33Q/WzF7bBkVvhEWDlcBiUyZaim5CpFQwAAACceyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQ29udmVyc2lvbk1lYXN1cmVtZW50IiwiZXhwaXJ5IjoxNjQzMTU1MTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlLCJ1c2FnZSI6InN1YnNldCJ9"><script src="https://securepubads.g.doubleclick.net/gpt/pubads_impl_2021111601.js" async=""></script></head>
   </head>
   <body class="">
      <div id="MasterContainer">
         <?php include_once "updateinfo.php"; ?>
         <?php if(!isset($_SESSION['id'])){ header('Location: login.aspx'); die(); } ?>
         <?php include_once "2014navbar.php"; ?>
         <?php include_once "updatestuff.php"; ?>

         <div id="BodyWrapper">
            <div id="RepositionBody">
               <div id="Body" style="width:970px">
			   <div id="HomeContainer" class="home-container">
                    <?php
            $id=$_SESSION['id'];
            $user="";$about="";
            $new = $_GET['feedid'];
            if($new == '34') { ?>
            <link rel="stylesheet" href="Feed.css" />
            <meta name="theme-color" content="#FFFF00">
        <meta property="og:title" content="Squared Feed ID 34">
        <meta property="og:url" content="https://www.squared.cf">
        <meta property="og:description" content="Welcome to the secret Squared feed section, no character limit, no message cooldown, no filter, go crazy.">
        <meta property="og:type" content="Website">
        <meta property="og:image" content="https://squared.cf/img/logo.svg">
                <div style="margin-left: 10px;width: 1020px;" class="divider">
<div id="statusUpdateBox" class="middle-column-box" style="background-color: rgb(230, 230, 230);padding: 3px;">
<div>
    <form action="messagesecretchat.php" method="post" id="addfeedtofeedyea">
<input name="txtStatusMessage" type="text" id="txtStatusMessage" maxlength="3243141" class="translate text-box text-box-large" style="width: 920px; float: left;" placeholder="What are you up to?" value="">
<span class="btn-control btn-control-large" style="padding: 0 20px !important; float: right;" id="shareButton" href="javascript:{}" onclick="document.getElementById('addfeedtofeedyea').submit();">Share</span>
</form>
<img id="loadingImage" class="status-update-image" style="display: none" alt="Sharing..." src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif">
<div class="clear"></div>
</div>
</div>
 <div id="FeedificationsContainer" class></div>
<div id="FeedContainer" class="middle-column-box feed-container">
<h2>Secret Chat</h2>
<div id="FeedPanel">
<div id="AjaxFeed" class="text">
    <?php
    $resultsperpage = 100;

            $sql = "SELECT count(*) FROM `secretchat`";
            $result = $db->prepare($sql);
            $result->execute();
            $usercount = $result->fetchColumn();

            $numberofpages = ceil($usercount/$resultsperpage);

            if($page < 1) $page = 1;
            $thispagefirstresult = ($page-1)*$resultsperpage;

        $lol = $db->prepare("SELECT * FROM secretchat ORDER BY date DESC LIMIT ".$thispagefirstresult.",".$resultsperpage);
        $lol->execute();
        while ($row = $lol->fetch())
        {
            echo '
            <div class="divider-top feed-container">
<div class="feed-image-container notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '" class="feed-asset">
<img class="feed-asset-image" title="' . $row['user'] . '" alt="' . $row['user'] . '" border="0" height="48" width="48" src="/get_avatar.php?id='.$row['madeby'].'">
</a>
</div>
<div class="feed-text-container text">
<span class="notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '">' . $row['user'] . '</a><br>
<div class="Feedtext">"' . $row['content'] . '"</div>
</span>
<span style="display: block; padding-top: 5px; color: #AAA; font-size: 11px;">' . date('F jS Y', strtotime($row['date'])) . ' at ' . date('g:i A', strtotime($row['date'])) . ' | Feed Message ID ' . $row['id'] . '</span>
</div>';
        }
    ?>
</div>
</div>
<div style="clear:both"></div>
</div>
            <?php } elseif($new == '23') { ?>
            <link rel="stylesheet" href="Feed.css">
<meta name="theme-color" content="#FFFF00">
        <meta property="og:title" content="Squared Feed ID 34">
        <meta property="og:url" content="https://www.squared.cf">
        <meta property="og:description" content="Welcome to the secret Squared feed section, no character limit, no message cooldown, no filter, go crazy.">
        <meta property="og:type" content="Website">
        <meta property="og:image" content="https://squared.cf/img/logo.svg">
                <div style="margin-left: 10px;width: 1020px;" class="divider">
<div id="statusUpdateBox" class="middle-column-box" style="background-color: rgb(230, 230, 230);padding: 3px;">
<div>
    <form action="feedadd3.php" method="post" id="addfeedtofeedyea">
<input name="txtStatusMessage" type="text" id="txtStatusMessage" maxlength="3243141" class="translate text-box text-box-large" style="width: 920px; float: left;" placeholder="What are you up to?" value="">
<span class="btn-control btn-control-large" style="padding: 0 20px !important; float: right;" id="shareButton" href="javascript:{}" onclick="document.getElementById('addfeedtofeedyea').submit();">Share</span>
</form>
<img id="loadingImage" class="status-update-image" style="display: none" alt="Sharing..." src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif">
<div class="clear"></div>
</div>
</div>
 <div id="FeedificationsContainer" class></div>
<div id="FeedContainer" class="middle-column-box feed-container">
<h2>devvy chat</h2>
<div id="FeedPanel">
<div id="AjaxFeed" class="text">
    <?php
    $resultsperpage = 50;

            $sql = "SELECT count(*) FROM `secretchat2`";
            $result = $db->prepare($sql);
            $result->execute();
            $usercount = $result->fetchColumn();

            $numberofpages = ceil($usercount/$resultsperpage);

            if($page < 1) $page = 1;
            $thispagefirstresult = ($page-1)*$resultsperpage;

        $lol = $db->prepare("SELECT * FROM secretchat2 ORDER BY date DESC LIMIT ".$thispagefirstresult.",".$resultsperpage);
        $lol->execute();
        while ($row = $lol->fetch())
        {
            echo '
            <div class="divider-top feed-container">
<div class="feed-image-container notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '" class="feed-asset">
<img class="feed-asset-image" title="' . $row['user'] . '" alt="' . $row['user'] . '" border="0" height="48" width="48" src="/get_avatar.php?id='.$row['madeby'].'">
</a>
</div>
<div class="feed-text-container text">
<span class="notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '">' . $row['user'] . '</a><br>
<div class="Feedtext">"' . $row['content'] . '"</div>
</span>
<span style="display: block; padding-top: 5px; color: #AAA; font-size: 11px;">' . date('F jS Y', strtotime($row['date'])) . ' at ' . date('g:i A', strtotime($row['date'])) . ' | Feed Message ID ' . $row['id'] . '</span>
</div>';
        }
    ?>
</div>
</div>
<div style="clear:both"></div>
</div>
            <?php } elseif($new == '128') { ?>
<div id="ctl00_cphRoblox_ContainerPanel">
<div id="BrowseContainer" style="text-align: center">
<div style="width: 970px; height: 28px; margin-bottom: 10px; clear: both;">
<form action="feedadd4.php" method="post" id="addfeedtofeedyea">
<span class="btn-control btn-control-large" style="padding: 0 20px !important; float: center;" id="shareButton" href="javascript:{}" onclick="document.getElementById('addfeedtofeedyea').submit();">Generate Invite Key</span>
</form>
<br>
<div style="float:center;min-height:600px">
<table class="table" cellspacing="0" cellpadding="0" border="0" id="_ctl0_cphRoblox_gvPlacesBrowsed">
<tbody>
<tr class="table-header">
<th class="Avatar">Inviter Avatar</th>
<th class="Member" style="width:126px;">Inviter Name</th>
<th class="Description" style="width:435px;">Code</th>
<th class="Date" style="width:85px;">Invite Creation Date</th>
<th class="" style="width:255px;border-right: 1px solid #cccccc">Used</th>
</tr>
<?php
                    if(!isset($_GET['page'])) {
                        $page = 1;
                    }else{
                        $page = $_GET['page'];
                    }

                    if(!isset($_GET['page'])) {
                        $pageor = 1;
                    }else{
                        $pageor = $_GET['page'];
                    }

                    if(!isset($_GET['search'])) {
                        $search = "";
                    }else{
                        $search = $_GET['search'];
                    }

            $resultsperpage = 20;

            $sql = "SELECT count(*) FROM `invites` WHERE code LIKE '%$search%'";
            $result = $db->prepare($sql);
            $result->execute();
            $usercount = $result->fetchColumn();

            $numberofpages = ceil($usercount/$resultsperpage);

            if($page < 1) $page = 1;
            $thispagefirstresult = ($page-1)*$resultsperpage;

        $lol = $db->prepare("SELECT * FROM invites WHERE code LIKE '%$search%' ORDER BY creationdate DESC LIMIT ".$thispagefirstresult.",".$resultsperpage);
        $lol->execute();
        if($usercount < 1) {
            echo '
    <div class="alert alert-danger" role="alert">
    Nothing found.
    </div>';
        }
        while ($row = $lol->fetch())
        {
            $online = "offline";
            $online2 = "/img/Offline.png";
            if($row['online'] == 1) {
                $online = "online";
                $online2 = "/img/Online.png";
            } else { 
                $online = "offline";
                $online2 = "/img/Offline.png";
            }
            $username = $db->query("SELECT * FROM users WHERE id = '".$ep->number($row['inviter'])."'")->fetch()['user'];
            $asd = '<span> None </span';
            $asa = '';
            if ($row['admin'] == 'yes') {
                $asd = '<span style="color:#e74c3c"> Administrator </span>';
            } else {
                $asd = '<span> None </span';
            }
                            
                            if ($username == 'Squared') {
                                $asa = 'https://cdn.upload.systems/uploads/YvgXSiKt.png';
                            } elseif ($username == 'philosophy') {
                                $asa = 'https://cdn.upload.systems/uploads/YtitGcTj.png';
                            } else {
                                $asa = 'https://cdn.upload.systems/uploads/cvLoLw4Y.png';
                            }
                            $aeae = date("F jS Y", strtotime($row['creationdate']));
                            $jksdaf = $aeae;
            $blurb = $row['code'];
echo '
<tr class="table-item">
<td style="border-left: 1px solid #cccccc"><a class="roblox-avatar-image" data-user-id="' . $row['inviter'] . '" data-image-size="custom" data-image-size-x="64" data-image-size-y="64" href="/User.aspx?id=' . $row['inviter'] . '"><div style="position: relative;"><a href="/User.aspx?id=' . $row['inviter'] . '"><img title="' . $username . '" alt="' . $username . '" border="0" height="64" width="64" src="https://squared.cf/get_avatar?id=' . $row['inviter'] . '"></a></td>
<td><img src="' . $online2 . '" alt="' . $username . ' is ' . $online . '" style="border-width:0px;"> <a href="/User.aspx?id=' . $row['inviter'] . '">' . $username . '</a></td>
<td>' . $blurb . '</td>
<td>' . $jksdaf . '</td>
<td style="border-right: 1px solid #cccccc">' . $row['used'] . '</td>
</tr>';
}
echo '<div style="border-bottom: 1px solid #cccccc"></div>';
echo'<tr class="GridPager">
            <td colspan="4"><table border="0">
                    <tbody><tr>
                        ';
        if($page <= $page) {
            $pagefix = $page + 9;
        }
        if($pagefix > $numberofpages) {
            $pagefix = $numberofpages;
        }
        $page2 = $page - 1;
        $page3 = $page - 2;
        $page4 = $page - 3;
        $page5 = $page - 4;
        $page6 = $page - 5;
        // For ... thing
        //if($page == 7) { $pagetest3 = $page - 6; }
        //if($page == 8) { $pagetest3 = $page - 7; }
        //if($page == 9) { $pagetest3 = $page - 8; }
        //if($page == 10) { $pagetest3 = $page - 9; }
        //if($page == 11 || $page > 11) { $pagetest3 = $page - 10; }

        if($page > 7 || $page == 7) echo"<td><b><a href='/?feedid=128&page=1&search=" . $search . "'>... </a></b></td>";

        if($page == 1 OR $page == 2 OR $page == 3 OR $page == 4 OR $page == 5) {
        }else{
            echo"<td>
                            <b><a href='/?feedid=128&page=".$page6."&search=" . $search . "'>".$page6." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$page5."&search=" . $search . "'>".$page5." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$page4."&search=" . $search . "'>".$page4." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$page3."&search=" . $search . "'>".$page3." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$page2."&search=" . $search . "'>".$page2." </a></b>
                        </td>
                    ";
        }

        $pager = $page - 1;
        $pager1 = $page - 2;
        $pager2 = $page - 3;
        $pager3 = $page - 4;
        if($page == 5) {
            echo"<td>
                            <b><a href='/?feedid=128&page=".$pager3."&search=" . $search . "'>".$pager3." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$pager2."&search=" . $search . "'>".$pager2." </a></b>
                        </td>
                    <td>
                          <b><a href='/?feedid=128&page=".$pager1."&search=" . $search . "'>".$pager1." </a></b>
                        </td>
                    <td>
                           <b> <a href='/?feedid=128&page=".$pager."&search=" . $search . "'>".$pager." </a></b>
                        </td>
                    ";
        }else{
        }

        $pagej = $page - 1;
        $pagej1 = $page - 2;
        $pagej2 = $page - 3;
        if($page == 4) {
            echo"<td>
                            <b><a href='/?feedid=128&page=".$pagej2."&search=" . $search . "'>".$pagej2." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$pagej1."&search=" . $search . "'>".$pagej1." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$pagej."&search=" . $search . "'>".$pagej." </a></b>
                        </td>
                    ";
        }else{
        }

        $pagey = $page - 1;
        $pagey1 = $page - 2;
        if($page == 3) {
            echo"<td>
                            <b><a href='/?feedid=128&page=".$pagey1."&search=" . $search . "'>".$pagey1." </a></b>
                        </td>
                    <td>
                            <b><a href='/?feedid=128&page=".$pagey."&search=" . $search . "'>".$pagey." </a></b>
                        </td>
                    ";
        }else{
        }

        $paget = $page - 1;
        if($page == 2) {
            echo"<td>
                            <b><a href='/?feedid=128&page=".$paget."&search=" . $search . "'>".$paget." </a></b>
                        </td>
                    ";
        }else{
        }


        for ($page<=$pagefix;$page<=$pagefix;$page++) {
            if($pageor == $page){
                echo"<td><b><span>$page</span></b></td>";
            }else{
                echo "
                        <td>
                            <b><a href='/?feedid=128&page=".$page."&search=" . $search . "'>".$page." </a></b>
                        </td>
                        ";
            }
        }
echo "
<td><b><a href='/?feedid=128&page=$numberofpages&search=" . $search . "'>...</a></td></b>
                                    </tr>
                    </tbody></table></td>
        </tr>

        </tbody></table>";
        ?>
</div>
<div style="float:right;width:160px;">
</div>
<br style="clear:both">
</div>
</div>
<script type="text/javascript">
  $(function () {
  	$("#ctl00_cphRoblox_SearchTextBox").focus();
     });
</script>
<div style="clear:both"></div>
</div>
<?php } elseif($new == '68' && !($_SESSION['id'] == 3)) { ?>
            <link rel="stylesheet" href="Feed.css">
<meta name="theme-color" content="#FFFF00">
        <meta property="og:title" content="Squared Feed ID 34">
        <meta property="og:url" content="https://www.squared.cf">
        <meta property="og:description" content="Welcome to the secret Squared feed section, no character limit, no message cooldown, no filter, go crazy.">
        <meta property="og:type" content="Website">
        <meta property="og:image" content="https://squared.cf/img/logo.svg">
                <div style="margin-left: 10px;width: 1020px;" class="divider">
<div id="statusUpdateBox" class="middle-column-box" style="background-color: rgb(230, 230, 230);padding: 3px;">
<div>
    <form action="feedadd5.php" method="post" id="addfeedtofeedyea">
<input name="txtStatusMessage" type="text" id="txtStatusMessage" maxlength="3243141" class="translate text-box text-box-large" style="width: 920px; float: left;" placeholder="What are you up to?" value="">
<span class="btn-control btn-control-large" style="padding: 0 20px !important; float: right;" id="shareButton" href="javascript:{}" onclick="document.getElementById('addfeedtofeedyea').submit();">Share</span>
</form>
<img id="loadingImage" class="status-update-image" style="display: none" alt="Sharing..." src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif">
<div class="clear"></div>
</div>
</div>
 <div id="FeedificationsContainer" class></div>
<div id="FeedContainer" class="middle-column-box feed-container">
<h2>Katrina X Philosophy</h2>
<div id="FeedPanel">
<div id="AjaxFeed" class="text">
    <?php
    $resultsperpage = 50;

            $sql = "SELECT count(*) FROM `KxP`";
            $result = $db->prepare($sql);
            $result->execute();
            $usercount = $result->fetchColumn();

            $numberofpages = ceil($usercount/$resultsperpage);

            if($page < 1) $page = 1;
            $thispagefirstresult = ($page-1)*$resultsperpage;

        $lol = $db->prepare("SELECT * FROM KxP ORDER BY date DESC LIMIT ".$thispagefirstresult.",".$resultsperpage);
        $lol->execute();
        while ($row = $lol->fetch())
        {
            echo '
            <div class="divider-top feed-container">
<div class="feed-image-container notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '" class="feed-asset">
<img class="feed-asset-image" title="' . $row['user'] . '" alt="' . $row['user'] . '" border="0" height="48" width="48" src="/get_avatar.php?id='.$row['madeby'].'">
</a>
</div>
<div class="feed-text-container text">
<span class="notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '">' . $row['user'] . '</a><br>
<div class="Feedtext">"' . $row['content'] . '"</div>
</span>
<span style="display: block; padding-top: 5px; color: #AAA; font-size: 11px;">' . date('F jS Y', strtotime($row['date'])) . ' at ' . date('g:i A', strtotime($row['date'])) . ' | Feed Message ID ' . $row['id'] . '</span>
</div>';
        }
    ?>
</div>
</div>
<div style="clear:both"></div>
</div>

            <?php } else { ?>
            <link rel="stylesheet" href="Feed.css">
            <div>
<h1>Hello, <?php echo $_SESSION['user']; ?>!</h1>
</div>
<div style="width: 230px;float: left;">
<div class="left-column-boxes user-avatar-container divider-right divider-bottom">
<div id="UserAvatar" class="thumbnail-holder" style="width:210px; height:210px;">
<div class="roblox-avatar-image image-medium"><div style="position: relative;"><img border="0" height="210" width="210" src="/get_avatar.php?id=<?php echo $_SESSION['id']; ?>"></div></div>
</div>
<div id="UserInfo" class="text">

<br clear="all">
<br class="rbx2hide">
<div>
</div>
</div> </div>

<div class="left-column-boxes divider-right">
<div>
<h3 class="best-friends-title">My Best Friends</h3>
<div style="float: right; margin-right: 4px;">
<a href="#" class="btn-small btn-neutral">Edit</a>
</div>
<div class="clear"></div>
</div>
<div id="bestFriendsContainer" class="best-friends-container"><div class="best-friends">
<div class="user">
<div class="roblox-avatar-image" data-user-id="1" data-image-size="tiny"><div style="position: relative;"><a href="https://squared.cf/User.aspx?id=1"><img title="Squared" alt="Squared" border="0" height="48" width="48" src="https://squared.cf/get_avatar?id=1"></a></div></div>
<div class="info">
<img src="/img/Online.png" title="Online">
<a class="name" href="https://squared.cf/User.aspx?id=1">Squared</a>
<div class="status">"Hello! This is the official Squared account."</div>
</div>
<div class="clear"></div>
</div>
</div></div>
<div style="clear:both;"></div>
</div>
</div>
<div style="margin-left: 10px;float: left;width: 600px;" class="divider-right">
<div id="statusUpdateBox" class="middle-column-box" style="background-color: rgb(230, 230, 230);padding: 3px;">
<div>
    <form action="feedadd.php" method="post" id="addfeedtofeedyea">
<input name="txtStatusMessage" type="text" id="txtStatusMessage" maxlength="254" class="translate text-box text-box-large" style="width: 500px; float: left;" placeholder="What are you up to?" value="">
<span class="btn-control btn-control-large" style="padding: 0 20px !important; float: right;" id="shareButton" href="javascript:{}" onclick="document.getElementById('addfeedtofeedyea').submit();">Share</span>
</form>
<img id="loadingImage" class="status-update-image" style="display: none" alt="Sharing..." src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif">
<div class="clear"></div>
</div>
</div>
 <div id="FeedificationsContainer" class></div>
<div id="FeedContainer" class="middle-column-box feed-container">
<h2>My Feed</h2>
<div id="FeedPanel">
<div id="AjaxFeed" class="text">
    <?php
    $resultsperpage = 8;

            $sql = "SELECT count(*) FROM `feed`";
            $result = $db->prepare($sql);
            $result->execute();
            $usercount = $result->fetchColumn();

            $numberofpages = ceil($usercount/$resultsperpage);

            if($page < 1) $page = 1;
            $thispagefirstresult = ($page-1)*$resultsperpage;

        $lol = $db->prepare("SELECT * FROM feed ORDER BY date DESC LIMIT ".$thispagefirstresult.",".$resultsperpage);
        $lol->execute();
        while ($row = $lol->fetch())
        {
            echo '
            <div class="divider-top feed-container">
<div class="feed-image-container notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '" class="feed-asset">
<img class="feed-asset-image" title="' . $row['user'] . '" alt="' . $row['user'] . '" border="0" height="48" width="48" src="/get_avatar.php?id='.$row['madeby'].'">
</a>
</div>
<div class="feed-text-container text">
<span class="notranslate">
<a href="/User.aspx?id=' . $row['madeby'] . '">' . $row['user'] . '</a><br>
<div class="Feedtext">"' . $row['content'] . '"</div>
</span>
<span style="display: block; padding-top: 5px; color: #AAA; font-size: 11px;">' . date('F jS Y', strtotime($row['date'])) . ' at ' . date('g:i A', strtotime($row['date'])) . ' | Feed Message ID ' . $row['id'] . '</span>
</div>
</div>
';
        }
    ?>
</div>
<div id="AjaxFeedError" style="display: none" class="error-message">An error occurred while fetching your feed.</div>
</div>
</div>
</div>
<div class="clear"></div>
<div id="UserScreenContainer">
</div>
</div>
<div style="clear:both"></div>
</div>
            <?php }
            ?>
            </div>
            </div>
         </div>
         </div>
         <?php include "2014footer.php" ?>
   </body>
</html>