<div class="container" style="max-width:revert !important;margin-top: 20px;padding-right: 15px;padding-left: 15px;margin-right: 0;margin-left: 0;">
  <footer class="py-3 my-4" style="border: 1px solid #e6e6e6; background: #fff; border-radius: 0.25rem;">
    <p class="text-center" style="margin-top:0;margin-bottom:0;">© Squared 2021</p>
  </footer>
</div>