<?php
	header('Location: '.$_GET['r'],true);
	die();
?>