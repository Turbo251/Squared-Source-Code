<head>
<title>All Star - Squared</title>
    <meta property="og:site_name" content="Squared">
    <meta property="og:title" content="All Star - Squared">
    <meta property="og:type" content="profile">
    <meta property="og:url" content="">
    <meta property="og:description" content="Squared, it is website. He is for old brick-builder. Good for use.">
    <meta property="og:image" content="https://cdn.upload.systems/uploads/pDPrTMVK.png">
</head>
<body>
    <center>all star</center>
</body>