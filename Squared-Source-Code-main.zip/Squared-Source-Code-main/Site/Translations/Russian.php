<?php
class Russian {
    public function translate($v1,$v2) {
        $MyFeedText = 'My Feed';
        $HelloHomePageText = 'Hello,';
        
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capital') !== false) {
                return 'Mоя Cтена';
                die();
            } else {
                return 'моя cтена';
                die();
            }
        }
        if (stripos($v1, $HelloHomePageText) !== false) {
            if (stripos($v2, 'capital') !== false) {
                return 'Привет,';
                die();
            } else {
                return 'привет,';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        if (stripos($v1, $MyFeedText) !== false) {
            if (stripos($v2, 'capitalized') !== false) {
                return '';
                die();
            } else {
                return '';
                die();
            }
        }
        
        
        
        
        return $v1;
        die();
    }
}
?>