<?php
class Chinese {
	public function translate($v1) {
	    if ($v1) {
	        
	    } else {
	        return $v1;
	    }
	}
}
?>