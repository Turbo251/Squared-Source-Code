<?php
header("content-type: text/plain");
$char = "http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;http://www.exoro.ml/asset/?id=;";
die($char)
?>