<?php
include_once "updateinfo.php";
echo $_SESSION['id'];
echo $_SESSION['user'];
echo $_SESSION['email'];
?>