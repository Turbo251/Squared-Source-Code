<html>
<head><style>
table {
	border-collapse:collapse;
}
tr {
	border:none;
}
th, td {
	border-collapse:collapse;
	border: 1px solid black;
	padding-top:0;
	padding-bottom:0;
}
.verticalSplit {
	border-top:none;
	border-bottom:none;
}
.verticalSplit:first-of-type {
	border-left:none;
}
.verticalSplit:last-of-type {
	border-right:none;
}
</style></head>
<body><table>
<tr><td>
	<table>
	    <tr>
		<td class="verticalSplit">A</td>
	</tr>
	<tr>
		<td class="verticalSplit">A</td>
	</tr>
	<tr>
		<td class="verticalSplit">A</td>
	</tr>
	<tr>
		<td class="verticalSplit">A</td>
	</tr>
	
	</table></td>
</table></body>
</html>