<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" xmlns:fb="http://www.facebook.com/2008/fbml">
   <head>
      <?php include_once "2014head.php"; ?>
   </head>
   <body class="">
      <div id="MasterContainer">
         <?php include_once "updateinfo.php"; ?>
         <?php if(isset($_SESSION['id'])){ header('Location: /'); } ?>
         <?php include_once "2014navbar.php"; ?>
         <div id="BodyWrapper">
               <div id="RepositionBody">

<div id="Body" class="" style="width:970px">
<div id="HomeContainer" class="home-container" data-facebook-share="/facebook/share-character" data-update-status-url="/home/updatestatus" data-get-feed-url="/feeds/getuserfeed">
<div>
<h1>Hello, <span class="notranslate">Squared</span>!</h1>
</div>
<div class="left-column">
<div class="left-column-boxes user-avatar-container">


<div id="UserAvatar" class="thumbnail-holder" data-3d-thumbs-enabled="" data-url="img/rendertest.png" style="width:210px; height:210px;">
<div class="roblox-avatar-image image-medium" data-user-id="3298" data-image-size="custom" data-image-size-x="210" data-image-size-y="210" data-no-click="true" border="0" onerror="" alt="philosophy"><div style="position: relative;"><img title="philosophy" alt="philosophy" border="0" height="210" width="210" src="#"></div></div>
</div>
<div id="UserInfo" class="text">

<br clear="all">
<br class="rbx2hide">
<div>
</div>
</div> </div>

<div class="left-column-boxes">
<div>
<h3 class="best-friends-title">My Best Friends</h3>
<div class="edit-friends-button">
<a href="/my/EditFriends.aspx" class="btn-small btn-neutral">Edit</a>
</div>
<div class="clear"></div>
</div>
<div id="bestFriendsContainer" class="best-friends-container"><div class="best-friends">
</div></div>
<div style="clear:both;"></div>
</div>
<div class="left-column-boxes text">
<div id="fbNotLoggedIn">
<img border="0" alt="Facebook Connect" src="https://images.rbxcdn.com/4ec0c6c40a454f2f6537946d00f09b56.png">
<div style="text-align: left; margin: 5px">
Link your ROBLOX account with your Facebook account to let your Facebook friends see what you're doing on ROBLOX!<br>
</div>
<a class="facebook-login" href="#">
<span class="left"></span>
<span class="middle">Connect with Facebook<span>Connect with Facebook</span></span>
<span class="right"></span>
</a>
<div class="facepile">
<iframe src="https://www.facebook.com/plugins/facepile.php?%20app_id=190191627665278" scrolling="yes" frameborder="0" style="border: none; overflow: hidden; width: 210px;"></iframe>
<p style="color: Gray; font-size: smaller">Only your Facebook friends can see this.</p>
</div>
</div>
</div>
</div>
<div class="middle-column">
<div id="statusUpdateBox" class="middle-column-box status-update">
<div>
<input name="txtStatusMessage" type="text" id="txtStatusMessage" maxlength="254" class="translate text-box text-box-large status-textbox" placeholder="What are you up to?" value="">
<span class="btn-control btn-control-large share-button" id="shareButton">Share</span>
<img id="loadingImage" class="status-update-image" style="display: none" alt="Sharing..." src="https://images.rbxcdn.com/ec4e85b0c4396cf753a06fade0a8d8af.gif">
<div class="clear"></div>
</div>
</div>
<div id="FeedificationsContainer" class=""></div>
<div id="FeedContainer" class="middle-column-box feed-container">
<h2>My Feed</h2>
<div id="FeedPanel">
<div id="AjaxFeed" class="text"><div class="divider-top feed-container">No news about your friends... want to know what your friends are up to? <a href="/Browse.aspx">make some friends now.</a></div></div>
<div id="AjaxFeedError" style="display: none" class="error-message">An error occurred while fetching your feed.</div>
</div>
</div>
</div>
<div class="right-column">
<div id="RecentlyVisitedPlacesContainer" class="right-column-box">
<h3 style="padding-bottom: 6px;">Recently Played Games</h3>
<div id="RecentlyVisitedPlaces">
<div id="RecentlyVisitedPlaceTemplate" class="recent-place-container">
<div class="recent-place-thumb"></div>
<div class="recent-place-Info">
<div class="recent-place-name"></div>
<div class="recent-place-players-online text"></div>
</div>
</div>
<div id="SeeMore" style="display: none;">
<a href="/games?sortFilter=6" class="text-link">See More <img alt="See more! " src="https://images.rbxcdn.com/efe86a4cae90d4c37a5d73480dea4cb1.png" class="see-more-img"></a>
</div>
<div id="PlayGames" style="">
You haven't played any games recently.
<a href="/Games.aspx" class="text-link">Play Now <img alt="See more! " src="https://images.rbxcdn.com/efe86a4cae90d4c37a5d73480dea4cb1.png" class="see-more-img"></a>
</div>
</div>
<div id="Skyscraper-Ad" class="right-column-box">
<div style="width: 160px">
<span id="3439303639313930" class="GPTAd skyscraper" data-js-adtype="gptAd">
<script type="text/javascript">
            googletag.cmd.push(function () {
                googletag.display("3439303639313930");
            });
        </script>
<div id="google_ads_iframe_/1015347/Roblox_MyHome_Right_160x600_0__container__" style="border: 0pt none;"><iframe id="google_ads_iframe_/1015347/Roblox_MyHome_Right_160x600_0" name="google_ads_iframe_/1015347/Roblox_MyHome_Right_160x600_0" width="160" height="600" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" src="javascript:" <html=""><body style='background:transparent'></body></html>"" style="border: 0px; vertical-align: bottom;"></iframe></div><iframe id="google_ads_iframe_/1015347/Roblox_MyHome_Right_160x600_0__hidden__" name="google_ads_iframe_/1015347/Roblox_MyHome_Right_160x600_0__hidden__" width="0" height="0" scrolling="no" marginwidth="0" marginheight="0" frameborder="0" src="javascript:" <html=""><body style='background:transparent'></body></html>"" style="border: 0px; vertical-align: bottom; visibility: hidden; display: none;"></iframe></span>
<div class="ad-annotations " style="width: 160px">
<span class="ad-identification">Advertisement</span>
<a class="BadAdButton" href="/Ads/ReportAd.aspx" title="click to report an offensive ad">Report</a>
</div>
</div> </div>
</div>
<div class="clear"></div>
<div id="UserScreenContainer">
</div>
</div>
<div style="clear:both"></div>
</div>
</div>
</div>
            </div>
      </div>
   </body>
</html>