;// bundle: Resources___Messages___e3a0b3c3b5da85e88ef03a794e78d3f8_m
;// files: modules/Resources/Messages.js

;// modules/Resources/Messages.js
typeof Resources=="undefined"&&(Resources={}),Resources.Messages={sorry:"We're sorry; an unexpected error occurred. Please refresh the page or try again.",noMessages:"You have no messages.",messages:"Messages"};