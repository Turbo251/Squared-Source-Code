# Squared Source Code
 old description: "Blame Philosophy, he should fuck off with his ass skidded source code. Only if he did not act like a little asshole lmao. This source is messy, crap and skidded lol."
I am good with philosophy, the old description is just an archive, but PLEASE do not use this for your own revival, it is a horrible dumpster, message from phil:
"update 9/14/2022:
 
to you guys who are making revivals of squared: STOP.

the old november 2021 source code is full of vulnerabilities,

and once people fully learn how all the code works they can start exploiting those vulnerabilities.
 
i've been seeing a lot of revivals using squared source code from 10 months ago.

**PLEASE** don't use the old squared source code, its very vulnerable and is a huge mess.

*if you don't even know PHP then dont even try*

i also cant believe y'all idiots actually made revivals OF SQUARED

i wouldn't recommend starting a revival in the first place as it is a very hard thing to maintain and can give you major anxiety


y'all 11 year olds aren't ready to own a revival especially when it gets popular




anyways if you're planning on making a revival, learn how to code first, and **don't skid.**"
